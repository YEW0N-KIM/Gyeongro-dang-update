package com.acorn.project.tour.domain;

import org.json.JSONObject;

import com.acorn.project.like.domain.Like;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
@Data
@AllArgsConstructor
@NoArgsConstructor

public class TourDTO3 {
	
	Object expguide;
	Object infocenter;
	Object restdate;
	Object parking;
	

}
