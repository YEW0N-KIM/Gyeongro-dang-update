package com.acorn.project.login.domain;

import lombok.Data;

@Data
public class updateHeatDTO {
	// 유저 온도
	private String user_heat;
	// 유저 코드
	private String user_code;
}
